[1] Close Application
[2] Automatic Installer.cmd
[3] Start Application