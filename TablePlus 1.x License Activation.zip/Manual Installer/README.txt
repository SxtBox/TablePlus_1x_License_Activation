[1] Close Application
[2] SHOW HIDE FILES
[3] Run Block Connection.cmd
[4] Copy All files From /License/ And Paste to C:\Users\YOUR_USERNAME\AppData\Local\com.tinyapp.TablePlus
[5] Start Application